import React from 'react';

const Events = () => {
    console.log("hello");
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'Right',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Welcome to GeeksforGeeks Events</h1>
	</div>
);
};

export default Events;
