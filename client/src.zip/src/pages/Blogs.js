import React, {useState, useEffect} from 'react';

import Link from '@mui/material/Link';
import { styled } from '@mui/system';
import TablePaginationUnstyled from '@mui/base/TablePaginationUnstyled';

import "./Box.css";

import { Card } from "react-bootstrap";




  const Blogs = () => {

    const [matches, setMatches] =useState([]);
  
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);
    useEffect(()=>{
    getMatches(page*rowsPerPage,rowsPerPage);},[]);
    
    
    const handleChangePage = (event, newPage) => {
      setPage(newPage);
      getMatchesChange(newPage*rowsPerPage,rowsPerPage);
      console.log(newPage*rowsPerPage,rowsPerPage);
    };
  
    const handleChangeRowsPerPage = (event) => {
      setRowsPerPage(parseInt(event.target.value, 10));
      setPage(0);
      getMatchesChange(0,parseInt(event.target.value, 10));
    };
  
    function getMatchesChange(skip,limit)
    {
      console.log("http://localhost:5000/matches?"+"skip="+skip+"&limit="+limit);
      fetch(
        "http://localhost:5000/matches?"+"skip="+skip+"&limit="+limit)
                    .then((res) => res.json())
                    .then((json) => {
                       setMatches(json);
                       console.log(json);
                    });
  
    }
    
  
    function getMatches()
    {
      fetch(
        "http://localhost:5000/matches/")
                    .then((res) => res.json())
                    .then((json) => {
                       setMatches(json);
                       console.log(json);
                    });
    };
  
    const renderCard = (card, index) => {
      return (
        <Card key={index} className="box">
          <Card.Body className='boxheader'>
            <Card.Title classname="tit">{card.team1} vs {card.team2}</Card.Title>
            <Card.Text classname="venue">{card.venue_name}</Card.Text>
            <Link href={"/matches/"+card.match_id}>{card.winner+" won by "+card.win_margin+" "+card.win_type}</Link>
          </Card.Body>
        </Card>
      );
    };
  
    return <div className="grid">{matches.map(renderCard)}</div>;
  
 
  };
  


export default Blogs;



