import ReactDOM from "react-dom";
import React from 'react';

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import Blogs from "./pages/Blogs";
import Contact from "./pages/Contact";
import Match from "./pages/Match"
import Player from "./pages/Player"
import Pointstable from "./pages/Pointstable"
import Navbar from './Components/Navbar';




export default function App() {
  return (
    <div className="bkg">
    <BrowserRouter>
      <Navbar />
      <Routes>
          <Route index element={<Home />} />
          <Route path="matches" element={<Blogs />} />
          <Route path="/matches/:match_id" element={<Match />}/>
          <Route path="/players/:player_id" element={<Player />}/>
          <Route path="/pointstable/:year" element={<Pointstable />}/>
          {/* <Route path="/summary/:match_id" element={<Summary />} /> */}
      </Routes>
    </BrowserRouter>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));