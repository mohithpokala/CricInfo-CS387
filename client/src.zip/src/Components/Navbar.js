import React from 'react';
import {
  Nav,
  NavLink,
  Bars,
  NavMenu,
  NavBtn,
  NavBtnLink,
} from './NavbarElements';
  
const Navbar = () => {
  return (
    <>
      <Nav>
        <Bars />
  
        <NavMenu>
          <NavLink to='/matches' activeStyle>
            Match
          </NavLink>
          <NavLink to='/home' activeStyle>
            Events
          </NavLink>
          <NavLink to='/players' activeStyle>
            Player_info
          </NavLink>
          <NavLink to='/points_table' activeStyle>
            Points Table
          </NavLink>
          {/* Second Nav */}
          {/* <NavBtnLink to='/sign-in'>Sign In</NavBtnLink> */}
        </NavMenu>
      </Nav>
    </>
  );
};
  
export default Navbar;