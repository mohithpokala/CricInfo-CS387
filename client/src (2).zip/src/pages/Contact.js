import React from 'react';
const Contact = () => {
    return <h1>SCorecard</h1>;
  };
  
  export default Contact;